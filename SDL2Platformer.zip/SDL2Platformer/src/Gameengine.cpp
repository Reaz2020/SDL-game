#include <SDL2/SDL.h>
#include "System.h"
#include <iostream>
#include "Bullet.h"
#include "Gameengine.h"
#include "Component.h"
#include "Enemybullet.h"
#include "Basicsprite.h"
#include "Minienemy.h"

using namespace std;


namespace cwing {
	

	void GameEngine::addToScreen(Component* sprite) {
		comps.push_back(sprite);
	}//addtoscreen sprite
	
	
	void GameEngine::run() {
		
		while (!quit) {

			bool playeralive = false,enemyalive = false;

			nextTick = SDL_GetTicks() + duration;

			SDL_Event game;
			while (SDL_PollEvent(&game)) {
				switch (game.type) {
				case SDL_QUIT: 
					setQuit(true); //end the game
					break;
				case SDL_KEYDOWN:
					for (Component* sprite : comps)
						sprite->keyAction(game); //keypressed event
					break;
				case SDL_KEYUP:
					for (Component* sprite : comps)
						sprite->keyAction(game); //key not pressed event
					break;
				
				}//event handling

			}//while game event
			
			SDL_SetRenderDrawColor(sys.getRen(), 154, 134, 134, 255);//background color handling(r,g,b,a)
			SDL_RenderClear(sys.getRen()); //clear it

			
			for (Component* sprite : comps) {
				sprite->draw();
			}//drawing all components

			
			for (Component* sprite : comps) {
				sprite->shotAction(&comps);
				if (sprite->getPlayerfired() == true) {
					Bullet* bullet = Bullet::getInstance(sprite->getRect().y , "res/laser.png"); // if bullet is shot,then creating the instance of bullet 
					bulletGone.push_back(bullet); // to keep record of bullets were shot then drawing the bullet sprite and clearing it later
				}	//check if shotaction is called now and  bullet is called, then creating it and shoot					
				
			}//to handle the player bullet components and to keep the record of bullets were shot to make sprite of them
			

			for (Component* sprite : comps) {
					sprite->enemyBulletAction(&comps);
					if (sprite->getEnemyshoot() == true) {
						Enemybullet* bullet = Enemybullet::getInstance(sprite->getRect().y , "res/enemybullet.png");//if enemybullet is shot,then creating the instance of enemybullet 
						enemyBulletGone.push_back(bullet); // to keep record of enemybullets were shot then drawing the enemybullet sprite and clearing it later
					}	//check if enemybulletaction is called now and  enemybullet is called, then creating it and shoot					
					
				}//to handle the player bullet components and to keep the record of bullets were shot to make sprite of them

			for (Component* sprite : bulletGone) {
				addToScreen(sprite);//adding all the player bullet sprite to the screen
			}
			
			bulletGone.clear(); //clearing all bullet from the vector

			for (Component* sprite : enemyBulletGone) {
				addToScreen(sprite);//adding all the enemy bullet sprite to the screen
			}

			enemyBulletGone.clear(); //clearing all bullet from the vector

			Basicsprite* basicsprite = Basicsprite::getInstance(375,230,250,250, "res/gameover.png"); //creating instance for gameover screen
			over.push_back(basicsprite); //adding the sprite to vector

			Basicsprite* basicsprite1 = Basicsprite::getInstance(375,230,250,250, "res/win.png"); //creating instance for you win screen
			win.push_back(basicsprite1); //adding the sprite to vector


			for (Component* sprite : comps) {
				sprite->enemyAction(&comps);
			}//handling enemy action

			
			SDL_RenderPresent(sys.getRen());


			for (Component* sprite : comps )
			{
				if(sprite->getRect().w==100) // if seeing any comps have a player rect
					playeralive = true;
			}

			for (Component* sprite : comps )
			{
				if(sprite->getRect().w==80) //// if seeing any comps have an enemy rect
					enemyalive = true;
			}
	
			
			for (std::vector<Component*>::iterator it = comps.begin(); it != comps.end(); ++it) {
				if ((*it)->getClearsprite()) {
					Component* temp = *it;
					remove.push_back(temp);
					delete temp;
				}//if any comps clearing sprite is called

			}



			for (Component* sprite : remove) {
				for (vector<Component*>::iterator i = comps.begin();
					i != comps.end();)
					if (*i == sprite) {
						i = comps.erase(i);
					}
					else
						i++;
			}//removing components


			remove.clear();//clearing remove vactor

			if(playeralive==false )
				{
					for (Component* sprite : over) {
							addToScreen(sprite); // adding game over screen
						}

				}
				over.clear(); //clearing game over sprite

			if(enemyalive==false)
			{
				for (Component* sprite : win) {
							addToScreen(sprite); // adding you win screen
						}

			}
				win.clear(); //clearing you win sprite
			
			delay = nextTick - SDL_GetTicks();
			if (delay > 0) {
				SDL_Delay(delay);
			} 
	
			
		}

	}//run

	
	GameEngine ::~GameEngine()
	{
		
		
		for (Component* sprite : comps) {
			delete sprite;
		}//deleting all sprite in components

		for (Component* sprite : bulletGone) {
			delete sprite;
		}//deleting all player bullet sprite

		for (Component* sprite : enemyBulletGone) {
			delete sprite;
		}//deleting all enemy bullet sprite

		for (Component* sprite : remove) {
			delete sprite;
		}//deleting all sprite from remove

		for (Component* sprite : win) {
			delete sprite;
		}//deleting sprite from win vector

		for (Component* sprite : over) {
			delete sprite;
		}// deleting sprite from over vector
		
	}//~GameEngine

}//namespace