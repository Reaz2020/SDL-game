#include "Enemybullet.h"


namespace cwing {
	Enemybullet::Enemybullet(const int y, const char* p) :Sprite(800, y+40  , 20, 20, p)
	{
		setEnemybullet(true);
	}//Enemybullet()

	void Enemybullet::enemyBulletAction(std::vector<Component*>* sprite) {
		rect.x -=enemyBulletVelocity;
		if (rect.x < -enemyBulletVelocity) {
			setClearsprite(true);
		}		
	}//enemybulletaction()
	
	
	Enemybullet::~Enemybullet()
	{
	}//~~Enemybullet()
	
}//namespace