#include "Player.h"
#include<bits/stdc++.h>

using namespace std;

namespace cwing {
	Player::Player( const char* p) : Sprite(100, 100, 100, 100, p)
	{
		
	}//Player

	void Player::keyAction(const SDL_Event& eve)
	{
		if (eve.type == SDL_KEYDOWN) {
			if (SDLK_DOWN == eve.key.keysym.sym) {
				isDown = true;
			}//if down key is pressed

			if (SDLK_UP == eve.key.keysym.sym) {
				isUp = true;
			}//if upper key is pressed

			if (SDLK_SPACE == eve.key.keysym.sym) {
				bulletFired = true;
			}//if space is pressed
		}

		if (eve.type == SDL_KEYUP) {
			if (SDLK_DOWN == eve.key.keysym.sym) {
				isDown = false;
			}//if down key is removed from press

			if (SDLK_UP == eve.key.keysym.sym) {
				isUp = false;
			}//check if upper key is removed from press

			if (SDLK_SPACE == eve.key.keysym.sym) {
				bulletFired = false;
			}//check if space key is removed from press
		}

	}//player keyaction()



	void Player::shotAction(std::vector<Component*>* sprite) {
		if (bulletDelay > 0) {
			bulletDelay--;
			setPlayerfired(false);
		}//Bullet delay
		
		if (bulletFired && bulletDelay == 0) {
				bulletDelay = shotDelay; 
				setPlayerfired(true);
		}//shot bullet

		if (isDown==true && (isUp == false)) {

			if (getRect().y > (sys.getH() - 100)) {
				rect.y += 0;
			}//cant move to down anymore if it reached the lower screen
			else {
				rect.y += 5;
			}//else move down
		}//down key is clicked

		if ((isDown == false) && isUp == true) {
			if (getRect().y < 0) {
				rect.y += 0;
			}//if close to the upper screen then cant move up anymore
			else {
				rect.y -= 5;
			}//else move up
		}//up key is clicked
		
		
	}//shotaction() && movement


	Player::~Player()
	{
	}//~Player()

}//namespace