#include "Bullet.h"


namespace cwing {
	Bullet::Bullet(const int y, const char* p) :Sprite(100, y+40  , 20, 20, p)
	{
		setBullet(true);
	}//Bullet()

	void Bullet::shotAction(std::vector<Component*>* sprite) {
		rect.x +=bulletVelocity;
		if (rect.x < -bulletVelocity || rect.x > sys.getW()) { // if bullet is out of window screen
			setClearsprite(true);
		}		
	}//shotaction()
	
	
	Bullet::~Bullet()
	{
	}//~~bullet()
	
}//NameSpace