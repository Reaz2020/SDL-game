// #include <crtdbg.h>
#include<cstdio>
#include<sstream>
#include<cstdlib>
#include<cctype>
#include<cmath>
#include<algorithm>
#include<random>
#include<set>
#include<queue>
#include<stack>
#include<list>
#include<iostream>
#include<fstream>
#include<numeric>
#include<string>
#include<vector>
#include<cstring>
#include<map>
#include<iterator>	
#include <chrono>
#include "System.h"
#include <SDL2/SDL.h>
#include "Gameengine.h"
#include "Sprite.h"
#include "Minienemy.h"
#include "Player.h"
#include "Mainenemy.h"
#include "Basicsprite.h"



using namespace cwing;
using namespace std;


mt19937 rng(chrono::steady_clock::now().time_since_epoch().count());

int main() {

	
	GameEngine aerospace;
	
	Player* spaceship = Player::getInstance( "res/spaceship.png"); // creating instance for player
	
	Minienemy* mini1 = Minienemy::getInstance(600,100, 80, 80, "res/enemy.png"); //creating instance for minienemy
	Minienemy* mini2 = Minienemy::getInstance(800,250,80, 80, "res/enemy.png"); //creating instance for minienemy
	Minienemy* mini3 = Minienemy::getInstance(200, 350, 80, 80, "res/enemy.png"); //creating instance for minienemy
	Minienemy* mini4 = Minienemy::getInstance(400, 500, 80, 80, "res/enemy.png"); //creating instance for minienemy
	Minienemy* mini5 = Minienemy::getInstance(300, 600, 80, 80, "res/enemy.png"); //creating instance for minienemy

	Mainenemy* mainE = Mainenemy::getInstance(800,430,80,80, "res/mainenemy.png"); //creating instance for mainenemy

	Basicsprite* ba[15];
	for (int i = 0; i < 15; i++) {
        int x = (rng() %
           (1000 - 10 + 1)) + 10;
        int y = (rng() %
           (700 - 10 + 1)) + 10;
        ba[i] = Basicsprite::getInstance(x,y,25,20, "res/stone5.png");
    } //creating instance for background stones

    for(auto i : ba)
    {
    	aerospace.addToScreen(i); //adding stones to the screen
    }


	aerospace.addToScreen(spaceship); //adding player to the screen
	
	aerospace.addToScreen(mini1); //adding minienemy to the screen
	aerospace.addToScreen(mini2); //adding minienemy to the screen
	aerospace.addToScreen(mini3); //adding minienemy to the screen
	aerospace.addToScreen(mini4); //adding minienemy to the screen
	aerospace.addToScreen(mini5); //adding minienemy to the screen

	aerospace.addToScreen(mainE); //adding mainenemy to the screen
	
	aerospace.run(); //calling the gameengine to run the game
	
}//main