#include "Mainenemy.h"

namespace cwing {
	Mainenemy::Mainenemy(const int x, int y, int w, int h, const char* p) :Sprite(x, y, 80, 80, p)
	{
		setMainenemy(true); //main enemy is launched
		setEnemyfired(true); //enemy bullet is fired
	}//Mainenemy()

	
	void Mainenemy::moveAction()
	{
			if (getRect().y < 10) {
				setMovement(-5);
			}// if mainenemy is close to upper screen then stop and then start movement to down
			if (getRect().y > (sys.getH() - 80)) {
				setMovement(5);
			}//if mainenemy is close to the down screen then start moving to up 
			
			rect.y = rect.y - getMovement();

	}//moveAction()

	void Mainenemy::enemyBulletAction(std::vector<Component*>* sprite)
	{

		if (bulletDelay > 0) {
			bulletDelay -= 10;
			setEnemyfired(false);
		}//enemyBullet delay
		
		if (bulletDelay == 0 ) {
			bulletDelay = fireDelay; 
			setEnemyfired(true);
		}
	}


	Mainenemy::~Mainenemy()
	{

	}

}//namespace