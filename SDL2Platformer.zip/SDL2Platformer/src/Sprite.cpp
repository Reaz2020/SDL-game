#include "Sprite.h"
#include <SDL2/SDL_image.h>
#include "System.h"
#include "Gameengine.h"
#include <iostream>
#include <string>

using namespace std;

namespace cwing {
	Sprite::Sprite(int x, int y, int w, int h, const char* p) : Component(x,  y, w,  h)
	{
		surface_sprite = IMG_Load(p);
		if (surface_sprite == nullptr) {
			throw invalid_argument("No Sprite to show");
		}
		
		texture_sprite = SDL_CreateTextureFromSurface(sys.getRen(), surface_sprite);
		SDL_FreeSurface(surface_sprite);

	}//Sprite()
	
	
	void Sprite::draw() {
		
	const SDL_Rect& rect = getRect();
	SDL_RenderCopy(sys.getRen(), texture_sprite, NULL, &rect);
		
	}//draw()

	void Sprite::shotAction(std::vector<Component*>* sprite) {
		moveAction();
		shotCollission(sprite);
	}//shotaction()			

	void Sprite::enemyBulletAction(std::vector<Component*>* sprite) {
			enemyBulletCollission(sprite);
	}//enemybulletaction()

	void Sprite::enemyAction(std::vector<Component*>* sprite) {
			enemyCollission(sprite);
	}//enemyaction()


	void Sprite::shotCollission(std::vector<Component*>* sprite) {
		const SDL_Rect& rect = getRect();
		const SDL_Rect* tempRect = &rect;
		for (Component* bullet : *sprite) {
			if ((bullet->getBullet() == true) && (getMini() == true || getMainenemy() == true)) {
				const SDL_Rect& rectC = bullet->getRect();
				const SDL_Rect* temprectC = &rectC;
				if (SDL_HasIntersection(tempRect, temprectC) == SDL_TRUE) {

						bullet->setClearsprite(true);
						setClearsprite(true);

				}//check if the minienemy or mainenemy and bullet rect is collided on that postion 
				

			}//if the rects are enemy and bullet 

		}
		
	}//collission()	


	void Sprite::enemyBulletCollission(std::vector<Component*>* sprite) {
		const SDL_Rect& rect = getRect();
		const SDL_Rect* tempRect = &rect;
		for (Component* bullet : *sprite) {
			if ((bullet->getEnemybullet() == true )) {
				const SDL_Rect& rectC = bullet->getRect();
				const SDL_Rect* temprectC = &rectC;
				if (SDL_HasIntersection(tempRect, temprectC) == SDL_TRUE) {

					if ((bullet->getEnemybullet()) && (getRect().w ==100|| getRect().w==20)) {
						bullet->setClearsprite(true);
						setClearsprite(true);
					} // if bullet is collided with player
					else if( (bullet->getEnemybullet()) && (getRect().w==80))
					{
						bullet->setClearsprite(true);
					} // if enemy bullet is collided with mini enemy

				}//if intersected the bullet with anysprite
				

			}

		}
		
	}//enemybulletcollision()	


	void Sprite::enemyCollission(std::vector<Component*>* sprite) {
		const SDL_Rect& rect = getRect();
		const SDL_Rect* tempRect = &rect;
		if(getRect().w==100 && getRect().h==100)
		for (Component* enemy : *sprite) {
			const SDL_Rect& rectC = enemy->getRect();
			const SDL_Rect* temprectC = &rectC;
			if(enemy->getRect().w==80 && enemy->getRect().h==80)
				if(SDL_HasIntersection(tempRect, temprectC) == SDL_TRUE) {
								enemy->setClearsprite(true);
								setClearsprite(true);
					} // if minienemy and player is collided each other
				}	

	}//enemycollision()		
						

	Sprite::~Sprite()
	{
		SDL_DestroyTexture(texture_sprite);

	}//~sprite()

}//namespace