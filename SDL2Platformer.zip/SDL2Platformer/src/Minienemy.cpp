#include "Minienemy.h"


namespace cwing {
	Minienemy::Minienemy(const int x, int y, int w, int h, const char* p) :Sprite(x, y, 80, 80, p)
	{
		setMini(true);
	}//Minienemy()

	
	void Minienemy::moveAction()
	{

		if (getRect().y > 500) {

			if (getRect().x < 50) {
				setMovement(-5);
			}// if mini enemy is close to the left screen then move to right
			if (getRect().x > (sys.getW() - 300)) {
				setMovement(5);
			}//if mini enemy is close to the main enemy then move to left  
			rect.x = rect.x - getMovement();
		}//some mini will move left first
		
		if (getRect().y <= 500) {
			if (getRect().x < 50) {
				setMovement(5);
			}
			if (getRect().x > (sys.getW() - 300)) {
				setMovement(-5);
			}
			rect.x = rect.x + getMovement();
		}//some mini will move right first

	}//moveAction()

	void Minienemy::enemyAction(std::vector<Component*>* sprite)
	{

	} //enemy collission action

	Minienemy::~Minienemy()
	{
	}

	

}//namespace