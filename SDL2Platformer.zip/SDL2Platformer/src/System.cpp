#include "System.h"
#include <iostream>
#include <SDL2/SDL.h>

using namespace std;

namespace cwing {

	System sys;
	
	System::System()
	{
		SDL_Init(SDL_INIT_EVERYTHING);
		win = SDL_CreateWindow("Aerospace", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, w, h, 0);
		ren = SDL_CreateRenderer(win, -1, 0);
		TTF_Init();
		font = TTF_OpenFont("res/sans.ttf", 24);
		
	}//system()


	System::~System()
	{
		SDL_DestroyWindow(win);
		SDL_DestroyRenderer(ren);
		TTF_CloseFont(font);
		TTF_Quit();
		SDL_Quit();
		
	}//~System()
 
	
}//namespace