#include "Basicsprite.h"

namespace cwing {
	Basicsprite::Basicsprite(const int x, int y, int w, int h, const char* p) :Sprite(x, y,w,h, p)
	{

	}//Basicsprite()

	

	Basicsprite::~Basicsprite()
	{
	}

	

}//namespace