#include "Component.h"
#include "System.h"


namespace cwing {

	Component::~Component()
	{

	}// ~Component()

}//namespace