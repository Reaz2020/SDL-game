#ifndef Basicsprite_H
#define Basicsprite_H
#include "Sprite.h"
#include "System.h"
namespace cwing {
	class Basicsprite : public Sprite {
	public:
		
		
		static Basicsprite* getInstance(const int x, int y, int w, int h, const char* p) {return new Basicsprite(x, y, w, h, p);}
		
		
		~Basicsprite();


	protected:
		
		Basicsprite(const int x, int y, int w, int h, const char* p);
		

	private:
	
		Basicsprite(const Basicsprite&) = delete; //stopping from copying itself 
		const Basicsprite& operator=(const Basicsprite&) = delete; //stopping from copying itself 

		
	};// class

}//namespace

#endif
