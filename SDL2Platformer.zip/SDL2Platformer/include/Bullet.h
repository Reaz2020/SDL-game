#ifndef BULLET_H

#define BULLET_H

#include "Sprite.h"

#include"System.h"

namespace cwing {
	class Bullet : public Sprite
	{
	public:
		
		static Bullet* getInstance(const int x,  const char* p) { return new Bullet(x, p); }
		
		void shotAction(std::vector<Component*>*); //player bullet action
		
		~Bullet();
	protected:
		Bullet(const int x,  const char* p);

	private:
		
		int bulletVelocity = 5;

		Bullet(const Bullet&) = delete;//stopping from copying itself 
		
		const Bullet& operator=(const Bullet&) = delete;//stopping from copying itself 
	};//class

}//namespace

#endif