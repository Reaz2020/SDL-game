#ifndef COMPONENT_H

#define COMPONENT_H

#include <SDL2/SDL.h>
#include <vector>
#include <SDL2/SDL_image.h>
namespace cwing {

	class Component
	{
	public:
		virtual void draw() = 0;
	    SDL_Rect getRect() const { return rect; } //getting rect position
		virtual void keyDown(const SDL_Event&) {} //key is pressed event
		virtual void keyUp(const SDL_Event&) {} //key isn't pressed event
		virtual void keyAction(const SDL_Event&) {} //player key action
		
		void setMini(bool x) { isMini = x; } //setting minienemy sprite
		void setMainenemy(bool x) {isMainenemy = x; } //setting mainenemy sprite
		void setBullet(bool x) { isBullet = x; } //setting player bullet sprite
		void setEnemybullet(bool x) {isEnemybullet = x;} //setting enemy bullet sprite
		void setClearsprite(bool x) { clearsprite = x; } //setting clear sprite
	    void setPlayerfired(bool x) { bulletfired = x; } //setting if player fired bullet
	    void setEnemyfired(bool x) { enemybulletfired = x; } //setting if mainenemy fired bullet

		
		bool getClearsprite() const { return clearsprite; } //getting clear sprite value
		bool getPlayerfired() const { return bulletfired; } //getting if player fired bullet
		bool getEnemyshoot() const { return enemybulletfired; } //getting if enemy fired bullet
		bool getMini() const { return isMini; } //getting if minienemy
		bool getMainenemy() const { return isMainenemy;} //getting if mainenemy
		bool getBullet() const { return isBullet; } //getting player bullet
		bool getEnemybullet() const {return isEnemybullet;} //getting enemy bullet
		
		virtual void shotAction(std::vector<Component*>*) {} //player bullet action && movement action
		virtual void moveAction() {} //enemy movement action
		virtual void enemyBulletAction(std::vector<Component*>*) {} //enemy bullet action
		virtual void enemyAction(std::vector<Component*>*){} //minienemy collision action
		virtual void enemyCollission(std::vector<Component*>*) {} //mini enemy collision


		
		virtual ~Component();
	protected:
		Component(int x, int y, int w, int h) : rect{ x,y,w,h } {}
		SDL_Rect rect;
	private:
		bool clearsprite = false;
		bool bulletfired = false;
		bool isMini = false;
		bool isMainenemy = false;
		bool isBullet = false;
		bool isEnemybullet = false;
		bool enemybulletfired = false;
		Component(const Component&) = delete; //stopping from copying itself 
		const Component& operator=(const Component&) = delete; //stopping from copying itself 
	}; //class
} //namespace

#endif