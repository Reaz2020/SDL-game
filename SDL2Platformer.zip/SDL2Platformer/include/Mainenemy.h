#ifndef Mainenemy_H

#define Mainenemy_H

#include "Sprite.h"
#include "System.h"

namespace cwing {
	class Mainenemy : public Sprite {
	public:
		
		
		static Mainenemy* getInstance(const int x, int y, int w, int h, const char* p) {return new Mainenemy(x, y, w, h, p);}
		
		void setMovement(int i) {movement = i;}
		
		int getMovement() const { return movement;}
	    
		void moveAction();

		void enemyBulletAction(std::vector<Component*>*);
		
		~Mainenemy();


protected:
		
	Mainenemy(const int x, int y, int w, int h, const char* p);
		

private:
	
	int movement = 5;
	int bulletDelay = 0;
	int fireDelay = 250;


	Mainenemy(const Mainenemy&) = delete;
	const Mainenemy& operator=(const Mainenemy&) = delete;
		
	};// class

	
}//namespace


#endif
