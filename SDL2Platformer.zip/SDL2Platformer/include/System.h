#ifndef SYSTEM_H

#define SYSTEM_H

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>

namespace cwing {

	class System
	{
	public:
		System();
		
		SDL_Renderer* getRen() { return ren; }
		TTF_Font* getFont() { return font; }
		SDL_Window* getWin() { return win; }
		
		int getH() const { return h; }
		int getW() const { return w; }
		
		~System();
	protected:
		
		SDL_Window* win;
		SDL_Renderer* ren;
		TTF_Font* font;
	
	private:
		
		int w = 1000;
		int h = 700;
	};//class

	extern System sys;

}//namespace

#endif