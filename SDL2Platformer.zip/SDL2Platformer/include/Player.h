#ifndef Player_H

#define Player_H

#include "Sprite.h"
#include"System.h"
#include "Bullet.h"


namespace cwing {

	
	class Player : public Sprite
	{
	public:
		
		static Player* getInstance( const char* p) { return new Player( p); }
		
		void keyAction(const SDL_Event&);
		
		void shotAction(std::vector<Component*>*);
		
		~Player();
	protected:
		Player(const char* p);
		
	private:
		bool bulletFired = false;
		bool isDown = false;
		bool isUp = false;
 		int bulletDelay = 0;
	    int shotDelay = 35;
		Player(const Player&) = delete;//stopping from copying itself 
		const Player& operator=(const Player&) = delete;//stopping from copying itself 
	};//class

}//namespace

#endif