#ifndef Minienemy_H

#define Minienemy_H

#include "Sprite.h"
#include "System.h"

namespace cwing {
	class Minienemy : public Sprite {
	public:
		
		static Minienemy* getInstance(const int x, int y, int w, int h, const char* p) {return new Minienemy(x, y, w, h, p);}
		
		void setMovement(int i) {movement = i;}
		
		int getMovement() const { return movement;}
	    
		void moveAction();

		void enemyAction(std::vector<Component*>*);
	
		~Minienemy();


protected:
		
	Minienemy(const int x, int y, int w, int h, const char* p);
		

private:
	
	int movement = 5;
	Minienemy(const Minienemy&) = delete;//stopping from copying itself 
	const Minienemy& operator=(const Minienemy&) = delete;//stopping from copying itself 

	};// class

}//namespace

#endif
