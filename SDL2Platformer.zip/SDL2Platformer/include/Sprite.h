#ifndef SPRITE_H

#define SPRITE_H

#include "Component.h"
#include <SDL2/SDL_image.h>
#include <string>
#include <iostream>

namespace cwing {

	class Sprite : public Component
	{
	public:
		
		static Sprite* getInstance(const int x, int y, int w, int h, const char* p) { return new Sprite(x,y,w,h, p); }
		
		void draw();
		
		void shotAction(std::vector<Component*>*);

		void enemyAction(std::vector<Component*>*);

		void enemyBulletAction(std::vector<Component*>*);
		
		void shotCollission(std::vector<Component*>*);
		
		void enemyBulletCollission(std::vector<Component*>*);

		void enemyCollission(std::vector<Component*>*);


		
		~Sprite();
	protected:
		
		Sprite(int x, int y, int w, int h, const char* p);
	private:
		
		SDL_Texture* texture_sprite;
		SDL_Surface* surface_sprite;
		Sprite(const Sprite&) = delete;//stopping from copying itself 
		const Sprite& operator=(const Sprite&) = delete;//stopping from copying itself  
	};//class

}//namespace

#endif