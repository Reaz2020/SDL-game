#ifndef SESSION_H

#define SESSION_H

#include "Component.h"
#include <vector>


#define FPS 60

namespace cwing {

	class GameEngine
	{
	public:
		
		void addToScreen(Component*); 

		void run();

		void setQuit(bool x) { quit = x;}

		~GameEngine();
	
	private:

		bool quit = false;
		std::vector<Component*> comps; //declaring vector for components
		std::vector<Component*> bulletGone; //declaring vector for bullet shots
		std::vector<Component*> enemyBulletGone; //declaring vector for enemy bullet shots
		std::vector<Component*> remove; //declaring vector for clearing sprite
		std::vector<Component*> over; //declaring vector for game over sprite
		std::vector<Component*> win; //declaring vector for player win sprite

		int delay;

		const int duration = 1000/FPS;

		Uint32 nextTick;
	};//class

}//NameSpace

#endif