#ifndef Enemybullet_H

#define Enemybullet_H

#include "Sprite.h"

#include"System.h"

namespace cwing {
	class Enemybullet : public Sprite
	{
	public:
		
		static Enemybullet* getInstance(const int x,  const char* p) { return new Enemybullet(x, p); }
		
		void enemyBulletAction(std::vector<Component*>*);
		
		~Enemybullet();
	protected:
		Enemybullet(const int x,  const char* p);

	private:
		
		int enemyBulletVelocity = 5;
		Enemybullet(const Enemybullet&) = delete;//stopping from copying itself 
		const Enemybullet& operator=(const Enemybullet&) = delete;//stopping from copying itself 
	};//class

}//Namespace

#endif